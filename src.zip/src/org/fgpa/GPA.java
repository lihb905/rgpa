package org.fgpa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;

import org.chocosolver.solver.ResolutionPolicy;
import org.chocosolver.solver.Solution;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.search.loop.monitors.IMonitorRestart;
import org.chocosolver.solver.search.loop.monitors.IMonitorSolution;
import org.chocosolver.solver.search.strategy.assignments.DecisionOperatorFactory;
import org.chocosolver.solver.search.strategy.decision.Decision;
import org.chocosolver.solver.search.strategy.selectors.variables.ActivityBased;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.variables.IntVar;

/**
 * This is the source code of the GPA part of the paper "Finding Good
 * Partial Assignments During Restart-based Branch and Bound Search, AAAI'23".
 * 
 * @author Hongbo Li
 * @since 08/29/2022
 */



public class GPA extends AbstractStrategy<IntVar> implements IMonitorSolution, IMonitorRestart {
	public final Solution lastSolution;
	public int lastObjective;
	public IntVar objectiveVariable;
	public Random random;
	public final int varNum;
	public IntVar[] vars;
	public Solver solver;
	
////////////The two linked list implement the solQueue	
	public LinkedList<Integer> objectiveValues;
	public LinkedList<int[]> solutionValues;

	public final int maxSolNum;
	public int recordSolNum;
	public final boolean isMaximize;
	public final boolean useTempCutoff;
	public HashMap<String, Assignment> assignmentMap;
	public double lubyCutoffTimes = 1;
	public boolean newSolutionFound;
	public int restartNum;
	public LinkedList<Assignment> paList;
	public LinkedList<Assignment> subtree;

	public GPA(IntVar[] vs, IntVar obj, Solution solution, int seed, Solver sv, int maxSN, boolean lubyInc) {
		this.lastSolution = solution;
		random = new Random(seed);
		solver = sv;
		solver.plugMonitor(this);
		varNum = vs.length;
		vars = vs;
		solutionValues = new LinkedList<int[]>();
		objectiveValues = new LinkedList<Integer>();
		objectiveVariable = obj;
		newSolutionFound = false;
		isMaximize = solver.getModel().getResolutionPolicy() == ResolutionPolicy.MAXIMIZE;
		assignmentMap = new HashMap<String, Assignment>();
		subtree = new LinkedList<Assignment>();
		lubyCutoffTimes = 1;
		useTempCutoff = lubyInc;
		maxSolNum = maxSN;
		restartNum = 1;
		recordSolNum = 0;
		paList = new LinkedList<Assignment>();
	}

	@Override
	public Decision<IntVar> getDecision() {
		if (ActivityBased.sampling) {
			return null;
		}
		while (!subtree.isEmpty()) {
			Assignment as = subtree.removeFirst();
			int currentVar = as.varID;
			int currentVal = as.value;
			IntVar best = vars[currentVar];
			if (best.isInstantiated()) {
				continue;
			}
			if (best.contains(currentVal)) {
				return solver.getDecisionPath().makeIntDecision(best, DecisionOperatorFactory.makeIntEq(),
						currentVal);
			}
		}
		return null;

	}

	@Override
	public void onSolution() {
		newSolutionFound = true;
		lastObjective = objectiveVariable.getValue();
	}

	public void generatePartialAssignment() {
		paList.clear();
		int[][] sols = new int[0][];
		sols = solutionValues.toArray(sols);
		double size = sols.length;
		for (int i = 0; i < size - 1; i++) {
			int[] sol1 = sols[i];
			int[] sol2 = sols[i + 1];
			ArrayList<Integer> list = compare(sol2, sol1);
			for (int k = 0; k < list.size(); k += 2) {
				int vid = list.get(k);
				int v = list.get(k + 1);
				Assignment as = new Assignment(vars[vid], vid, v);
				paList.add(as);
			}
		}
	}
	
	public void beforeRestart() {

		lubyCutoffTimes = 1;
		restartNum++;
		if (!paList.isEmpty()) {
			subtree.clear();
			subtree.addAll(paList);
			int n = paList.size() / 2;
			if (n == 0) {
				n = 1;
			}
			while (n > 0 && !paList.isEmpty()) {
				paList.removeLast();
				n--;
			}
		}
		if (newSolutionFound) {
			newSolutionFound = false;
			if (!ActivityBased.sampling) {
				if (solutionValues.size() == maxSolNum) {
					solutionValues.removeLast();
					objectiveValues.removeLast();
				}
				solutionValues.addFirst(getValuesFromSolution(lastSolution));
				recordSolNum++;
				objectiveValues.addFirst(lastObjective);
				if (objectiveValues.size() > 1) {
					generatePartialAssignment();
					subtree.clear();
					subtree.addAll(paList);
					if (useTempCutoff) {
						lubyCutoffTimes = restartNum;
					} else {
						lubyCutoffTimes = 1;
					}
				}
				restartNum = 1;
			}
		}

	}



	public int[] getValuesFromSolution(Solution sol) {
		int[] values = new int[varNum];
		for (int i = 0; i < varNum; i++) {
			values[i] = sol.getIntVal(vars[i]);
		}
		return values;
	}

	public ArrayList<Integer> compare(int[] worseSol, int[] betterSol) {
		ArrayList<Integer> results = new ArrayList<Integer>();
		for (int i = 0; i < varNum; i++) {
			int v1 = worseSol[i];
			int v2 = betterSol[i];
			if (v1 != v2) {
				results.add(i);
				results.add(v2);
//				System.out.print("X[" + i + "]=( " + v1 + " , " + v2 + " ),\t");
			}
		}
//		System.out.println();
//		System.out.println(results.size() / 2 + " / " + varNum);
//		System.out.println("----------");
		return results;
	}

}


class Assignment  {
	public String name;
	public IntVar var;
	public int value;
	public double score;
	public int varID;
	public double incTimes;

	public Assignment(IntVar vr, int vid, int v) {
		varID = vid;
		var = vr;
		value = v;
		name = getName(vid, v);
		score = 0;
		incTimes = 0;
	}

	public static String getName(int vid, int v) {
		return "X[" + vid + "]=" + v;
	}

	public void increScore(double d) {
		score += d;
		incTimes++;
	}

	public double getSumScore() {
		return score;
	}

	public double getAveScore() {
		return score / incTimes;
	}

	public void print() {
		System.out.print("(" + name + ", " + score + ") || ");
	}

	public int compareTo(Object o) {
		Assignment o2 = (Assignment) o;
		if (this.score == o2.score) {
			int id1 = this.varID;
			int id2 = o2.varID;
			if (id1 == id2) {
				return 0;
			} else {
				if (id1 < id2) {
					return 1;
				} else {
					return -1;
				}
			}
		}
		if (this.score > o2.score) {
			return 1;
		} else {
			return -1;
		}
	}

}

