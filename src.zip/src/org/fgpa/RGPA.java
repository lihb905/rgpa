package org.fgpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import org.chocosolver.solver.Solution;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.variables.IntVar;


/**
 * This is the source code of the RGPA part of the paper "Finding Good
 * Partial Assignments During Restart-based Branch and Bound Search, AAAI'23".
 * 
 * @author Hongbo Li
 * @since 08/29/2022
 */

public class RGPA extends GPA {

	public RGPA(IntVar[] vs, IntVar obj, Solution solution, int seed, Solver sv, int maxSN, boolean lubyInc) {
		super(vs, obj, solution, seed, sv, maxSN, lubyInc);
	}

	public void generatePartialAssignment() {

		paList.clear();
		assignmentMap.clear();
		int[] objs = new int[objectiveValues.size()];
		int index = 0;
		for (java.util.Iterator<Integer> ite = objectiveValues.iterator(); ite.hasNext();) {
			objs[index++] = ite.next();
		}
		double decayWeight = 0;
		int[][] sols = new int[0][];
		sols = solutionValues.toArray(sols);
		int range = sols.length / 2;

		for (int i = 0; i < range; i++) {
			int[] sol1 = sols[i];
			decayWeight = ((range - i) / range);
			for (int j = 0; j < range; j++) {
				int[] sol2 = sols[j + i + 1];
				ArrayList<Integer> list = compare(sol2, sol1);
				double score = objs[i] - objs[j];
				if (!isMaximize) {
					score = 0 - score;
				}
				score *= decayWeight;
				double upNum = list.size() / 2;
				score /= upNum;
				for (int k = 0; k < list.size(); k += 2) {
					int vid = list.get(k);
					int v = list.get(k + 1);
					String name = Assignment.getName(vid, v);
					if (assignmentMap.containsKey(name)) {
						Assignment as = assignmentMap.get(name);
						as.increScore(score);
					} else {
						Assignment as = new Assignment(vars[vid], vid, v);
						as.increScore(score);
						assignmentMap.put(name, as);
					}
				}
			}
		}
		for (Assignment as : assignmentMap.values()) {
			paList.add(as);
		}
		Assignment[] asArray = new Assignment[paList.size()];
		asArray = paList.toArray(asArray);
		Arrays.sort(asArray, Comparator.comparingDouble(Assignment::getAveScore));
		paList.clear();
		for (int i = asArray.length - 1; i >= 0; i--) {
			paList.addLast(asArray[i]);
//			asArray[i].print();
		}

	}

}
