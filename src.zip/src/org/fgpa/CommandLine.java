package org.fgpa;

import java.util.Arrays;
import java.util.Comparator;

import org.chocosolver.cutoffseq.LubyCutoffStrategy;
import org.chocosolver.parser.SetUpException;
import org.chocosolver.parser.flatzinc.Flatzinc;
import org.chocosolver.parser.flatzinc.ast.FGoal;
import org.chocosolver.solver.Model;
import org.chocosolver.solver.ResolutionPolicy;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.search.strategy.selectors.values.IntDomainBest;
import org.chocosolver.solver.search.strategy.selectors.values.IntDomainLast;
import org.chocosolver.solver.search.strategy.selectors.values.IntDomainMin;
import org.chocosolver.solver.search.strategy.selectors.values.IntValueSelector;
import org.chocosolver.solver.search.strategy.selectors.variables.ActivityBased;
import org.chocosolver.solver.search.strategy.selectors.variables.DomOverWDeg;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.search.strategy.strategy.IntStrategy;
import org.chocosolver.solver.variables.IntVar;


/**
 * This is an example to run the source code of RGPA proposed in paper "Finding Good
 * Partial Assignments During Restart-based Branch and Bound Search, AAAI'23".
 * 
 * @author Hongbo Li
 * @since 08/29/2022
 */


public class CommandLine {

	public static final String WDEG = "WDEG";
	public static final String ABS = "ABS";
	public static final String BASE = "Base";
	public static final String RGPA = "RGPA";
	public static final String GPA = "GPA";

	public static void main(String[] args) {
		args = new String[8];
		
		args[0] = "BM/cargo_coarsePiles_challenge07_1s_133.fzn";// specify a .fzn file here
		args[1] = "0";//random seed
		args[2] = "7200s";//timeout
		args[3] = ABS;// ABS for activity-based search, WDEG for dom/wdeg
		args[4] = RGPA;//BASE, GPA, RGPA
		args[5] = "20";//m, the maximum size of solQueue
		args[6] = "T";//T for using the temporary cutoff; F for not using that. T does not work if using BASE at args[4]
		args[7] = "T";//T for resetting the cutoff after a solution is found; F for not restting.
		if (args.length == 8) {
			solveAnInstance(args);
		} else {
			System.out.println("error!");
		}
	}
 
	public static void solveAnInstance(String[] args) {
		Model model = createModel(args[0]);
		IntVar[] dvars = FGoal.geneDecVarFromList();
		if (dvars == null || dvars.length == 0) {
			int vn = model.getNbVars();
			dvars = new IntVar[vn];
			for (int i = 0; i < vn; i++) {
				dvars[i] = (IntVar) model.getVar(i);
			}
		}
		Solver solver = model.getSolver();
		Arrays.sort(dvars, Comparator.comparingInt(IntVar::getId));
		configureSearch(solver, dvars, args[1], args[3], args[4], args[5], args[6], args[7]);

		solver.limitTime(args[2]);
		solve(solver);
	}

	public static void solve(Solver solver) {
		solver.showShortStatistics();
		if (solver.hasObjective()) {
			IntVar obj = (IntVar) solver.getModel().getObjective();
			boolean isMaximize = solver.getObjectiveManager().getPolicy() == ResolutionPolicy.MAXIMIZE;
			solver.findOptimalSolution(obj, isMaximize, null);
		} else {
			solver.solve();
		}
	}

	public static Model createModel(String fn) {
		Model model = null;
		try {
			if (!fn.endsWith(".fzn")) {
				fn = fn + ".fzn";
			}
			Flatzinc fzn = new Flatzinc();
			String[] param = { "-pa", "1", fn };
			if (fzn.setUp(param)) {
				fzn.createSolver();
				fzn.buildModel();
				model = fzn.getModel();
			}
		} catch (SetUpException e) {
			throw new Error(e.getMessage());
		}
		return model;
	}

	public static void configureSearch(Solver solver, IntVar[] dvars, String sd, String baseHeu, String fgpa, String ms,
			String inc, String reset) {
		boolean incRestart = false;
		if (inc.equals("T")) {
			incRestart = true;
		}
		boolean resetCutoffOnSolution = false;
		if (reset.equals("T")) {
			resetCutoffOnSolution = true;
		}
		int seed = Integer.parseInt(sd);
		Model model = dvars[0].getModel();
		IntValueSelector valueSelector;
		if (model.getResolutionPolicy() == ResolutionPolicy.SATISFACTION || !(model.getObjective() instanceof IntVar)) {
			valueSelector = new IntDomainMin();
		} else {
			valueSelector = new IntDomainBest();
			model.getSolver().attach(model.getSolver().defaultSolution());
			valueSelector = new IntDomainLast(model.getSolver().defaultSolution(), valueSelector, null);
		}

		AbstractStrategy<IntVar> baseVOH = null;
		switch (baseHeu) {

		case WDEG:
			baseVOH = new IntStrategy(dvars, new DomOverWDeg(dvars, 0), valueSelector);
			break;

		case ABS:
			baseVOH = new ActivityBased(dvars, valueSelector, seed);
			break;

		default:
			System.out.println("Error, No VOH found! exit ...");
			System.exit(0);
		}

		GPA topVOH = null;
		int maxSolNum = Integer.parseInt(ms);

		switch (fgpa) {
		case RGPA:
			topVOH = new RGPA(dvars, (IntVar) model.getObjective(), model.getSolver().defaultSolution(), seed, solver,
					maxSolNum, incRestart);
			break;
		case GPA:
			topVOH = new GPA(dvars, (IntVar) model.getObjective(), model.getSolver().defaultSolution(), seed, solver,
					maxSolNum, incRestart);
			break;
		default:
		}
		if (topVOH != null) {
			if (incRestart) {
				solver.setRestarts(count -> solver.getFailCount() >= count, new LubyCutImpr(dvars.length, topVOH),
						Integer.MAX_VALUE, resetCutoffOnSolution);
			} else {
				solver.setRestarts(count -> solver.getFailCount() >= count, new LubyCutoffStrategy(dvars.length),
						Integer.MAX_VALUE, resetCutoffOnSolution);
			}
			solver.setSearch(topVOH, baseVOH);
		} else {
			solver.setRestarts(count -> solver.getFailCount() >= count, new LubyCutoffStrategy(dvars.length),
					Integer.MAX_VALUE, resetCutoffOnSolution);
			solver.setSearch(baseVOH);
		}
		solver.setNoGoodRecordingFromRestarts();

	}

}
