package org.fgpa;

import org.chocosolver.cutoffseq.AbstractCutoffStrategy;

/**
 * This is the source code of the restart part of the paper "Finding Good
 * Partial Assignments During Restart-based Branch and Bound Search, AAAI'23".
 * 
 * @author Hongbo Li
 * @since 08/29/2022
 */

public class LubyCutImpr extends AbstractCutoffStrategy {

	private GPA fgs4COP;

	/**
	 * Current cutoff, starts at 1 and will be multiplied by {@link #scaleFactor}
	 * anytime {@link #getNextCutoff()} is called.
	 */
	private int un = 1;
	/**
	 * Current limit, which set {@link #un} to 1 when reached.
	 */
	private int vn = 1;

	/**
	 * A Luby cutoff strategy.
	 *
	 * @param s scale factor
	 */
	@SuppressWarnings("WeakerAccess")
	public LubyCutImpr(long s) {
		super(s);
	}

	public LubyCutImpr(long s, GPA fgs) {
		super(s);
		fgs4COP = fgs;
	}

	double grow = 1;

	public LubyCutImpr(long s, double g) {
		super(s);
	}

	@Override
	public long getNextCutoff() {
		if (fgs4COP == null) {
			grow = 1;
		} else {
			grow = fgs4COP.lubyCutoffTimes;
		}
		final long cutoff = (long) (scaleFactor * this.vn * grow);
		if ((this.un & -this.un) == this.vn) {
			this.un = this.un + 1;
			this.vn = 1;
		} else {
			this.vn = this.vn << 1;
		}
		return cutoff;
	}

	@Override
	public void reset() {
		un = vn = 1;
	}

	@Override
	public String toString() {
		return "LUBYImpr(s=" + scaleFactor + ",log2)";
	}

}
